import Fsm.Event;

public class Event_SYNACK extends Event {

	public Event_SYNACK(String name) {
		super(name);
	}

	public Event_SYNACK(String name, Object obj) {
		super(name, obj);
	}

}
