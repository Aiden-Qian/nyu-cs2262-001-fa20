import Fsm.Event;

public class Event_SDATA extends Event {

	public Event_SDATA(String name) {
		super(name);
	}

	public Event_SDATA(String name, Object obj) {
		super(name, obj);
	}

}
