import Fsm.Event;

public class Event_FIN extends Event {

	public Event_FIN(String name) {
		super(name);
	}

	public Event_FIN(String name, Object obj) {
		super(name, obj);
	}

}
