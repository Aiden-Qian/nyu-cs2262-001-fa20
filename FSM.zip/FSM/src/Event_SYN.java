import Fsm.Event;

public class Event_SYN extends Event {

	public Event_SYN(String name) {
		super(name);
	}

	public Event_SYN(String name, Object obj) {
		super(name, obj);
	}

}
