import Fsm.Event;

public class Event_ACTIVE extends Event {

	public Event_ACTIVE(String name) {
		super(name);
	}

	public Event_ACTIVE(String name, Object obj) {
		super(name, obj);
	}

}
