import Fsm.Event;

public class Event_TIMEOUT extends Event {

	public Event_TIMEOUT(String name) {
		super(name);
	}

	public Event_TIMEOUT(String name, Object obj) {
		super(name, obj);
	}

}
