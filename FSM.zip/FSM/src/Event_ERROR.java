import Fsm.Event;
public class Event_ERROR extends Event{

	public Event_ERROR(String name, Object obj) {
		super(name, obj);
	}
	
	public Event_ERROR(String name) {
		super(name);
	}
}
