import Fsm.Event;

public class Event_CLOSE extends Event {

	public Event_CLOSE(String name) {
		super(name);
	}

	public Event_CLOSE(String name, Object obj) {
		super(name, obj);
	}
}
