import Fsm.Event;

public class Event_ACK extends Event {

	public Event_ACK(String name) {
		super(name);
	}

	public Event_ACK(String name, Object obj) {
		super(name, obj);
	}

}
