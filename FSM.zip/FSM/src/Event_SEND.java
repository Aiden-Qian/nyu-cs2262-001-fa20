import Fsm.Event;
public class Event_SEND extends Event{

	public Event_SEND(String name) {
		super(name);
	}

	public Event_SEND(String name, Object obj) {
		super(name, obj);
	}
	
}
