import Fsm.Event;

public class Event_PASSIVE extends Event {

	public Event_PASSIVE(String name) {
		super(name);
	}

	public Event_PASSIVE(String name, Object obj) {
		super(name, obj);
	}

}
