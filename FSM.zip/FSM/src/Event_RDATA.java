import Fsm.Event;

public class Event_RDATA extends Event {

	public Event_RDATA(String name) {
		super(name);
	}

	public Event_RDATA(String name, Object obj) {
		super(name, obj);
	}

}
